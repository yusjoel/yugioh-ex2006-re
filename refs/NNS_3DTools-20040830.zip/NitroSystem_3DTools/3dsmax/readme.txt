*********************************************************************
* NITRO 3ds max 6 Exporter Ver 1.3.0                                       *
* August 19th, 2004                                     �@�@  �@�@�@�@�@�@             *
*********************************************************************
Contents:

(1) NITRO 3ds max 6 Exporter Software
(2) Installing the Software
(3) Revision History

========================================================================
(1) NITRO 3ds max 6 Exporter Software
========================================================================
File lists

./3dsmax6/plugcfg/IGameProp.xml
./3dsmax6/plugins/NITROExporter.dle
./3dsmax6/plugins/NITROMenu.dlu
./3dsmax6/plugins/NITROMorphMat.ms
./3dsmax6/plugins/NITROStdMat.ms
./3dsmax6/scripts/startup/NITROConvMat.ms
./3dsmax6/IGame.dll
./readme.txt
./revision.txt
./Setup_MaxPlugin.pdf
./NITRO_MaxPlugin.pdf

========================================================================
(2) Installing the Software
========================================================================
Please refer to the Setup_MaxPlugin.pdf for details.

========================================================================
(3) Revision History
========================================================================
August 19th, 2004

Fixed bug where apply was causing the n3es file to save into the folder of the current
max scene.  Also made the End To Start Interpolation checkbox have more space 
for characters for Japanese Max.

Fixed bug with forced full weight where the bone node index was off in certain cases 
when a vertex was influenced by multiple bones, but the one with the most influence
was an index other than 0.

Fixed bug where it might not put the vtx into the correct bone's local space if 
forceFullWeights was checked.

August 18th, 2004

Fixed Unite bug with skinned meshes.

Fixed bug when exporting a skinned mesh that contains some vertices that are not 
influenced by any bone and vertices that are influenced by one or more bones.  The 
bug was exporting envelope indices for vertices that had no bone influence.

August 17th, 2004

Fixed force weights bug where the forcing of weights of happening in ExportIMD after it
was needed in IRISExporter.  The code has been moved and the boneIdx member of
skinned vertices is now set correctly to index 0 when forcing full weight instead of -1.

Fixed bug where arrays were being indexed incorrectly when a scene contains a start 
index != 0.

August 12th, 2004

Added a progress bar to the dialog box for use when clicking Apply for export.  When
clicking apply, all children windows are disabled so that the user can't alter settings 
during export, which could crash the exporter.  The addition of this progress bar also 
fixed the problem where the export dialog would disappear as Max recaptured focus 
during it's progress bar update.  This also fixed the problem where the 3D Material 
editor would start up and then Max would take focus and hide it from view.

Changed output of the identity scale when ForceFullWeight is checked to (1.0,1.0,1.0) 
instead of (0.0,0.0,0.0).

August 11th, 2004

Changed the name attribute in the <polygon> tag list to display polygon # where # is 
a sequential numbering of the polygons.

August 10th, 2004

Fixed bug where it would output the incorrect amount of palettes if any were being 
shared.

Suppressed the overwrite dialog prompts when exporting from the file menu to the 
3D Material Editor and fixed bug where Apply was not saving set preferences, hence 
the output folder would change to be the 3D Material directory, regardless of the 
previous export location.

Fixed bug with node exporting where camera nodes were not being included in the 
node lists so node linking of the lists was incorrect (the brother node indices were off).

Changed code to round-up weights when printing to the IMD file.

Fixed bug with skinning warning where it was displaying a warning when a vertex had 
no bone influence upon it.  Also added an epsilon value to the comparison of whether 
or not the weights add up to 1.

August 6th, 2004

Changed about box date to 2004-08-06.
Added missing section of 16 bit tga code.

August 5th, 2004

Fixed bug with 16-bit TGAs that were exported.  They were 
returning an alpha value of 0 for each pixel which was causing 
all 16-bit images to display entirely transparent.  Put in an alpha 
check to see if the image is without an alpha channel, and if not,
the alpha is set to completely opaque.

August 4th, 2004

Fixed the crash bug when exporting a scene with camera.

August 3rd, 2004

Fixed bug with quad stripping where vector component checks (the function 
VecEqual) was not using an epsilon value to compare floats which was 
causing some of the quads to flicker when rendered.
Updated about box to be "Ver 1.3.0 ( 2004/08/03 )"

August 2nd, 2004

Official Release Ver 1.3.0

Note: Please see the revision.txt for the changes from the beta version.

Please contact support@noa.com for technical questions on Nintendo NITRO.

